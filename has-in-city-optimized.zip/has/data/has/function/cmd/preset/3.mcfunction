scoreboard players set countdown has_setting 3
scoreboard players set timer has_setting 300
scoreboard players set seeker has_setting 1
scoreboard players set gamemode has_setting 1
scoreboard players set decoy_detectable has_setting 1