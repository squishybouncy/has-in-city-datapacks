execute at @s align xz run worldborder center ~ ~
execute as @s at @s run spawnpoint @a ~ ~ ~
execute as @s run tp @a ~ ~ ~
gamemode creative @s
tellraw @a {"text": "New location has been set!", "color": "green", "bold": true}