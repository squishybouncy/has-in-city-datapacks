execute at @s run worldborder center ~ ~
execute as @s at @s run spawnpoint @a ~ ~ ~
execute as @s run tp @a ~ ~ ~

execute if score border has_setting matches 1 run worldborder set 100
execute if score border has_setting matches 2 run worldborder set 150
execute if score border has_setting matches 3 run worldborder set 200

tellraw @a {"text": "Set new location!", "color": "green", "bold": true}