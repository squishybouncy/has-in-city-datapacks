function has:cmd/reset
gamemode adventure @a

# First, force players who are pre-selected
execute as @a[team=has_next_seeker] run function has:game/set_seeker

# Then randomly fill remaining slots
execute if score seeker_count has_system < seeker has_setting run function has:game/pick_one_seeker

# Assign remaining players as hiders
team join has_hider @a[team=!has_seeker]

execute at @s run summon armor_stand ~ ~ ~ {Tags:["has_spawn_point"],Invisible:1b,Invulnerable:1b,Marker:1b}
tp @a @s

tellraw @a {"text": "Game started!", "color": "green", "bold": true}
execute as @a[team=has_hider] run title @a title {"text": "You are a Hider!", "color": "blue", "bold": true}
execute as @a[team=has_hider] run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 1 0.5
execute as @a[team=has_seeker] run title @a title {"text": "You are a Seeker!", "color": "red", "bold": true}
execute as @a[team=has_seeker] run playsound minecraft:entity.elder_guardian.curse player @s ~ ~ ~ 0.75 1

effect give @a[team=has_seeker] minecraft:blindness infinite 1 true
effect give @a[team=has_seeker] minecraft:slowness infinite 255 true
effect give @a[team=has_seeker] minecraft:weakness infinite 100 true
effect give @a[team=has_seeker] minecraft:glowing infinite 1 true

scoreboard players operation countdown_sec has_system = countdown has_setting
scoreboard players operation timer_sec has_system = timer has_setting

effect give @a minecraft:regeneration 3 255 true

scoreboard players set active has_system 1

execute as @r at @s as @e[type=minecraft:villager,sort=nearest,limit=1] run team join has_hider @s

execute store result bossbar minecraft:release_timer_bar max run scoreboard players get countdown_sec has_system
bossbar set minecraft:release_timer_bar visible true
