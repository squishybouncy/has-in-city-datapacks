function has:cmd/reset
gamemode adventure @a

execute as @r run team join has_seeker @s
execute if score seeker has_setting matches 2 as @r[team=!has_seeker] run team join has_seeker @r
execute as @a[team=!has_seeker] run team join has_hider @s

execute at @s run summon armor_stand ~ ~ ~ {Tags:["has_spawn_point"],Invisible:1b,Invulnerable:1b,Marker:1b}
tp @a @s

tellraw @a {"text": "Game started!", "color": "green", "bold": true}

effect give @a[team=has_seeker] minecraft:blindness infinite 1 true
effect give @a[team=has_seeker] minecraft:slowness infinite 255 true
effect give @a[team=has_seeker] minecraft:weakness infinite 100 true

scoreboard players operation countdown_sec has_system = countdown has_setting
scoreboard players operation timer_sec has_system = timer has_setting

effect give @a minecraft:regeneration 1 255 true

scoreboard players set active has_system 1
