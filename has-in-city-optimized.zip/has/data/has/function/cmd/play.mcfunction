function has:cmd/reset

team empty has_hider
team empty has_seeker
team empty has_spectator
team empty has_intermission

# Assign one random seeker, everyone else is a hider
execute as @r run team join has_seeker @s
execute as @a[team=!has_seeker] run team join has_hider @s

execute as @a[team=has_seeker] at @s run setblock ~ ~ ~ cobweb
execute as @a[team=!has_seeker] at @s run tp @a[team=!has_seeker] ~1.5 ~ ~

tellraw @a {"text": "Game started!", "color": "green", "bold": true}

# Apply seeker blindout based on countdown setting (1/2/3 = 60/90/120s)
effect give @a[team=has_seeker] minecraft:blindness infinite 1 true
effect give @a[team=has_seeker] minecraft:slowness infinite 255 true
effect give @a[team=has_seeker] minecraft:weakness infinite 100 true

execute if score countdown has_setting matches 1 run scoreboard players set countdown_sec has_system 60
execute if score countdown has_setting matches 2 run scoreboard players set countdown_sec has_system 90
execute if score countdown has_setting matches 3 run scoreboard players set countdown_sec has_system 120

# Set world border size (1/2/3 = 100/150/200 blocks radius)
execute if score border has_setting matches 1 run worldborder set 100
execute if score border has_setting matches 2 run worldborder set 150
execute if score border has_setting matches 3 run worldborder set 200

effect give @a minecraft:regeneration 1 255 true

scoreboard players set active has_system 1
