function has:cmd/reset

scoreboard players set game_state has_system 1
tp @a @s
gamemode adventure @a
execute at @s run summon armor_stand ~ ~ ~ {Tags:["has_spawn_point"],Invisible:1b,Invulnerable:1b,Marker:1b}
effect give @a minecraft:regeneration 3 255 true

# First, force players who are pre-selected
execute as @a[team=has_next_seeker] run function has:game/seeker_mgmt/set_seeker

# Then randomly fill remaining slots
execute if score seeker_count has_system < seeker has_setting run function has:game/seeker_mgmt/pick_one_seeker

# Assign remaining players as hiders
team join has_hider @a[team=!has_seeker]

tellraw @a {"text": "Game started!", "color": "green", "bold": true}
execute as @a[team=has_hider] run title @a title {"text": "You are a Hider!", "color": "blue", "bold": true}
execute as @a[team=has_hider] at @s run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 1 0.5
execute as @a[team=has_seeker] run title @a title {"text": "You are a Seeker!", "color": "red", "bold": true}
execute as @a[team=has_seeker] at @s run playsound minecraft:entity.elder_guardian.curse player @s ~ ~ ~ 0.75 1

effect give @a[team=has_seeker] minecraft:blindness infinite 1 true
effect give @a[team=has_seeker] minecraft:slowness infinite 255 true
effect give @a[team=has_seeker] minecraft:weakness infinite 100 true
effect give @a[team=has_seeker] minecraft:glowing infinite 1 true

scoreboard players operation beginning_cd_sec has_system = countdown has_setting
scoreboard players operation hasing_cd_sec has_system = timer has_setting

execute as @r at @s as @e[type=minecraft:villager,sort=nearest,limit=1] run team join has_hider @s
scoreboard players set @a[team=has_hider] has_invisible_time 0
tag @e[team=has_hider] add has_detectable

execute store result bossbar minecraft:has_release_timer_bar max run scoreboard players get beginning_cd_sec has_system
bossbar set minecraft:has_release_timer_bar visible true
