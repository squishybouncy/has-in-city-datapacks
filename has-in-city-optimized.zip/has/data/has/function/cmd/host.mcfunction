scoreboard players add @s has_isHost 1
execute if score @s has_isHost matches 2 run scoreboard players set @s has_isHost 0

execute if score @s has_isHost matches 1 run tellraw @a [{"selector":"@s"}, {"text":" is now the game host!", "color":"green", "bold":true}]
execute if score @s has_isHost matches 0 run tellraw @a [{"selector":"@s"}, {"text":" is no longer the game host.", "color":"red", "bold":true}]

function has:cmd/reset