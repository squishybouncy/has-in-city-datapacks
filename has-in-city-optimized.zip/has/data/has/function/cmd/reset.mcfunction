effect clear @a
effect give @a minecraft:regeneration 1 255 true

kill @e[tag=has_spawn_point]
kill @e[tag=has_entity]
kill @e[tag=has_decoy]
kill @e[tag=has_decoy_marker]

team empty has_hider
team empty has_seeker
team empty has_spectator
team empty has_intermission

execute as @a run team join has_intermission @s

scoreboard players set active has_system 0
scoreboard players set status has_system 0
scoreboard players set countdown_sec has_system -1
scoreboard players set timer_sec has_system -1
scoreboard players set second has_system 0
scoreboard players set xray_step has_system 10
scoreboard players set xray_detected has_system 0
scoreboard players set seeker_count has_system 0

scoreboard players set @a useItem 0
scoreboard players set @a useItemLast 0
scoreboard players set @a deaths 0
scoreboard players set @a cd_jump_boost 0
scoreboard players set @a cd_reveal_seeker 0
scoreboard players set @a cd_thermometer 0
scoreboard players set @a cd_xray 0

scoreboard players set @a temperature 0
scoreboard players set @a xray_user 0

scoreboard objectives setdisplay sidebar has_setting

execute as @a if score @s isHost matches 1 run give @s written_book[minecraft:custom_data={has_control:1b},minecraft:written_book_content={title:"HAS Control Panel",author:"SquishyBouncy",generation:0,pages:[["",{"text":"   ADMIN PANEL","bold":true,"color":"#555555"},"\n",{"text":"━━━━━━━━━━━━━━━\n","color":"#949494"},{"text":" [ RELOCATE ]","color":"#AA00FF","click_event":{"action":"run_command","command":"/function has:cmd/relocate"}},"\n",{"text":" [ START ]    ","color":"#00AA00","click_event":{"action":"run_command","command":"/function has:cmd/play"}},{"text":"[ END ]\n","color":"#AA0000","click_event":{"action":"run_command","command":"/function has:cmd/end"}},{"text":"━━━━━━━━━━━━━━━\n","color":"#949494"},{"text":"Countdown\n","bold":true,"color":"#333333"},{"text":"-60 ","color":"#FF5555","click_event":{"action":"run_command","command":"/scoreboard players remove countdown has_setting 60"}},{"text":"-10 ","color":"#FF5555","click_event":{"action":"run_command","command":"/scoreboard players remove countdown has_setting 10"}},{"text":"+10 ","color":"#55FF55","click_event":{"action":"run_command","command":"/scoreboard players add countdown has_setting 10"}},{"text":"+60\n","color":"#55FF55","click_event":{"action":"run_command","command":"/scoreboard players add countdown has_setting 60"}},{"text":"Timer\n","bold":true,"color":"#333333"},{"text":"-60 ","color":"#FF5555","click_event":{"action":"run_command","command":"/scoreboard players remove timer has_setting 60"}},{"text":"-10 ","color":"#FF5555","click_event":{"action":"run_command","command":"/scoreboard players remove timer has_setting 10"}},{"text":"+10 ","color":"#55FF55","click_event":{"action":"run_command","command":"/scoreboard players add timer has_setting 10"}},{"text":"+60\n","color":"#55FF55","click_event":{"action":"run_command","command":"/scoreboard players add timer has_setting 60"}},{"text":"Border\n","bold":true,"color":"#333333"},{"text":"-50 ","color":"#FF5555","click_event":{"action":"run_command","command":"/worldborder add -50"}},{"text":"-10 ","color":"#FF5555","click_event":{"action":"run_command","command":"/worldborder add -10"}},{"text":"+10 ","color":"#55FF55","click_event":{"action":"run_command","command":"/worldborder add 10"}},{"text":"+50\n","color":"#55FF55","click_event":{"action":"run_command","command":"/worldborder add 50"}},{"text":"Seekers\n","bold":true,"color":"#333333"},{"text":"[ -1 ]","color":"#FF5555","click_event":{"action":"run_command","command":"/scoreboard players remove seeker has_setting 1"}},{"text":"       ","color":"#333333"},{"text":"[ +1 ]\n","color":"#55FF55","click_event":{"action":"run_command","command":"/scoreboard players add seeker has_setting 1"}},{"text":"━━━━━━━━━━━━━━━\n","color":"#949494"}] , ["",{"text":"   MODE & ENTITY","bold":true,"color":"#555555"},"\n",{"text":"━━━━━━━━━━━━━━━\n","color":"#949494"},{"text":"Gamemode\n","bold":true,"color":"#555555"},{"text":"[ NORMAL ]","color":"#55FF55","click_event":{"action":"run_command","command":"/scoreboard players set gamemode has_setting 1"}},"\n",{"text":"[ HORROR ]","color":"#AA0000","click_event":{"action":"run_command","command":"/scoreboard players set gamemode has_setting 2"}},"\n\n",{"text":"Special Entities\n","bold":true,"color":"#555555"},{"text":"[ SPAWN VAS ]","color":"#00AAAA","click_event":{"action":"run_command","command":"/function has:mode_horror/spawn_entity"}},"\n\n",{"text":"━━━━━━━━━━━━━━━\n","color":"#949494"},{"text":"   (Page 2/2)","italic":true,"color":"#AAAAAA"}]]},minecraft:tooltip_display={hidden_components:["minecraft:written_book_content"]}]
execute as @a if score @s isHost matches 0 run clear @s minecraft:written_book

gamerule locator_bar false

bossbar set minecraft:release_timer_bar visible false
bossbar set minecraft:time_remaining_bar visible false