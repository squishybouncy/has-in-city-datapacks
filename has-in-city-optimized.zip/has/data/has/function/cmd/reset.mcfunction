effect clear @a
effect give @a minecraft:regeneration 3 255 true
clear @a minecraft:carrot_on_a_stick 10
clear @a minecraft:wooden_shovel 10
clear @a minecraft:netherite_sword 10

kill @e[tag=has_spawn_point]
kill @e[tag=has_entity_vas]
kill @e[tag=has_decoy]
kill @e[tag=has_decoy_marker]
kill @e[tag=has_sensor_marker]

team empty has_hider
team empty has_seeker
team empty has_spectator
team empty has_intermission
team empty has_next_seeker
execute as @a run team join has_intermission @s

scoreboard players set game_state has_system 0
scoreboard players set game_tick has_system 0
scoreboard players set beginning_cd_sec has_system -1
scoreboard players set hasing_cd_sec has_system -1
scoreboard players set hasing_60_sec has_system 60
scoreboard players set xray_step has_system 10
scoreboard players set xray_detected has_system 0
scoreboard players set seeker_count has_system 0

scoreboard players set @a has_useItem 0
scoreboard players set @a has_useItemLast 0
scoreboard players set @a has_deaths 0
scoreboard players set @a has_cd_jump_boost 0
scoreboard players set @a has_cd_reveal_seeker 0
scoreboard players set @a has_cd_thermometer 0
scoreboard players set @a has_cd_xray 0
scoreboard players set @a has_cd_sensor 0
scoreboard players set @a has_temperature 0
scoreboard players set @a has_xray_user 0
scoreboard players set @a has_invisible_time 0

scoreboard objectives setdisplay sidebar has_setting

tag @a remove has_detectable

gamerule locator_bar false

bossbar set minecraft:has_release_timer_bar visible false
bossbar set minecraft:has_time_remaining_bar visible false

clear @a written_book 100
execute as @a if score @s has_isHost matches 1 run function has:cmd/book