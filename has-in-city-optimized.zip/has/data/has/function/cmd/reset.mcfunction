effect clear @a
gamemode adventure @a

execute as @a run team join has_intermission @s

scoreboard players set active has_system 0
scoreboard players set countdown_sec has_system -1
scoreboard players set timer_sec has_system -1
scoreboard players set second has_system 0

scoreboard players set @a useItem 0
scoreboard players set @a useItemLast 0
scoreboard players set @a deaths 0
scoreboard players set @a cd_jump_boost 0

execute as @a if score @s isHost matches 1 run give @s written_book[minecraft:custom_data={has_control:1b},written_book_content={pages:[[["",{"text":"Game Controller","bold":true,"italic":true,"color":"#949494"},"\n",{"text":"-> Relocate","color":"#8c00ff","click_event":{"action":"run_command","command":"/function has:cmd/relocate"}},"\n",{"text":"-> Set Location","color":"#e1ff00","click_event":{"action":"run_command","command":"/function has:cmd/center"}},"\n",{"text":"-> Start","color":"#00ff04","click_event":{"action":"run_command","command":"/function has:cmd/play"}},{"text":" ","color":"#00ff04"},"\n",{"text":"-> End","color":"#ff0000","click_event":{"action":"run_command","command":"/function has:cmd/end"}},"\n",{"text":"Game Settings","bold":true,"italic":true,"color":"#a6a6a6"},"\n",{"text":"Border (Blocks)","color":"#e100ff"},"\n",{"text":"100","click_event":{"action":"run_command","command":"/scoreboard players set border has_setting 1"}}," | ",{"text":"200","click_event":{"action":"run_command","command":"/scoreboard players set border has_setting 2"}}," | ",{"text":"300","click_event":{"action":"run_command","command":"/scoreboard players set border has_setting 3"}},"\n",{"text":"Countdown (Minutes)","color":"#e100ff"},"\n",{"text":"1","click_event":{"action":"run_command","command":"/scoreboard players set countdown has_setting 1"}}," | ",{"text":"2","click_event":{"action":"run_command","command":"/scoreboard players set countdown has_setting 2"}}," | ",{"text":"3","click_event":{"action":"run_command","command":"/scoreboard players set countdown has_setting 3"}},"\n",{"text":"Timer (Minutes)","color":"#e100ff"},"\n",{"text":"5","click_event":{"action":"run_command","command":"/scoreboard players set timer has_setting 1"}}," | ",{"text":"10","click_event":{"action":"run_command","command":"/scoreboard players set timer has_setting 2"}}," | ",{"text":"15","click_event":{"action":"run_command","command":"/scoreboard players set timer has_setting 3"}},"\n",{"text":"Shrink Border?","color":"#00aaff"},"\n",{"text":"Yes","click_event":{"action":"run_command","command":"/scoreboard players set shrink has_setting 1"}}," | ",{"text":"No","click_event":{"action":"run_command","command":"/scoreboard players set shrink has_setting 0"}}]]],title:"HAS in City Control Panel",author:SquishyBouncy,generation:0},tooltip_display={hidden_components:[written_book_content]}]
execute as @a if score @s isHost matches 0 run clear @s minecraft:written_book