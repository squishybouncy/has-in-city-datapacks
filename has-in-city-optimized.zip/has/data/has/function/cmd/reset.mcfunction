effect clear @a
effect give @a minecraft:regeneration 1 255 true

kill @e[tag=has_spawn_point]
kill @e[tag=has_entity]

team empty has_hider
team empty has_seeker
team empty has_spectator
team empty has_intermission

execute as @a run team join has_intermission @s

scoreboard players set active has_system 0
scoreboard players set status has_system 0
scoreboard players set countdown_sec has_system -1
scoreboard players set timer_sec has_system -1
scoreboard players set second has_system 0
scoreboard players set xray_step has_system 10
scoreboard players set xray_detected has_system 0

scoreboard players set @a useItem 0
scoreboard players set @a useItemLast 0
scoreboard players set @a deaths 0
scoreboard players set @a cd_jump_boost 0
scoreboard players set @a cd_reveal_seeker 0
scoreboard players set @a cd_thermometer 0
scoreboard players set @a cd_xray 0

scoreboard players set @a temperature 0
scoreboard players set @a xray_user 0

scoreboard objectives setdisplay sidebar has_setting

execute as @a if score @s isHost matches 1 run give @s written_book[minecraft:custom_data={has_control:1b},written_book_content={pages:[[["",{"text":"Game Controller","bold":true,"italic":true,"color":"#949494"},"\n",{"text":"-> Relocate","color":"#8c00ff","click_event":{"action":"run_command","command":"/function has:cmd/relocate"}},"\n",{"text":"-> Start","color":"#00ff04","click_event":{"action":"run_command","command":"/function has:cmd/play"}},{"text":" ","color":"#00ff04"},"\n",{"text":"-> End","color":"#ff0000","click_event":{"action":"run_command","command":"/function has:cmd/end"}}]]],title:"HAS in City Control Panel",author:SquishyBouncy,generation:0},tooltip_display={hidden_components:[written_book_content]}]
execute as @a if score @s isHost matches 0 run clear @s minecraft:written_book

gamerule locator_bar false