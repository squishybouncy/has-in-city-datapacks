function has:cmd/end
gamemode spectator @s
tellraw @a [{"text": "Relocating... Click to set new location", "bold": true, "color": "light_purple","click_event":{"action":"run_command","command":"/function has:cmd/center"}}]