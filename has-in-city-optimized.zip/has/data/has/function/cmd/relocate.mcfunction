gamemode creative @s
worldborder set 1000000
tellraw @a {"text": "Relocating", "color": "light_purple", "bold": true}