tellraw @a {"text": ">>> Hide and Seek in City by SquishyBouncy <<<", "color": "green", "bold": true}
tellraw @a [{"text": "Click here or type '/function has:cmd/host' to become the game host.", "color": "light_purple","click_event":{"action":"run_command","command":"/function has:cmd/host"}}]
