function has:cmd/reset
clear @a
tellraw @a {"text": "Game ended!", "color": "red", "bold": true}