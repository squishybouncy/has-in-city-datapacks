clear @a
tellraw @a {"text": "Game ended!", "color": "red", "bold": true}

function has:cmd/reset