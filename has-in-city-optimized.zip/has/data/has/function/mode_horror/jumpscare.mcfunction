scoreboard players add entity_jumpscare_timer has_system 1

tp @s ~ ~ ~ facing entity @e[tag=has_entity,limit=1]
effect give @s minecraft:blindness 1 0 true 
effect give @s minecraft:slowness 1 255 true
effect give @s minecraft:glowing 1 0 true

execute if score entity_jumpscare_timer has_system matches 1 run playsound minecraft:entity.enderman.death ambient @s ~ ~ ~ 1 0.5
execute if score entity_jumpscare_timer has_system matches 1 run title @s title {"text":"☠","color":"white"}
