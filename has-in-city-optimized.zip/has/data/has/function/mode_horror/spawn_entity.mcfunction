scoreboard players set entity_jumpscare_timer has_system 0
kill @e[tag=has_entity]

execute as @e[tag=has_spawn_point] at @s run summon zombie ~ ~ ~ {Tags:["has_entity"],Invisible:1b,Invulnerable:1b,PersistenceRequired:1b,Silent:1b,equipment:{head:{id:player_head,count:1,components: {"minecraft:profile": {name: "Whyzka"}}}},attributes:[{id:follow_range,base:300f},{id:movement_speed,base:0.1f},{id:knockback_resistance,base:1f},{id:max_health,base:1024f}]}
execute as @r at @s run spreadplayers ~ ~ 15 30 false @e[tag=has_entity]
effect give @e[tag=has_entity] minecraft:invisibility 1000000 0 true
