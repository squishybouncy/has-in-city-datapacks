scoreboard players remove countdown_sec has_system 1
title @a actionbar [{"text":"Seeker releases in ","color":"red","bold":true},{"score":{"name":"countdown_sec","objective":"has_system"}}]