scoreboard players remove countdown_sec has_system 1

execute store result bossbar minecraft:release_timer_bar value run scoreboard players get countdown_sec has_system
bossbar set minecraft:release_timer_bar name {"color":"red", "text":"", "extra": ["Seekers will be released in: ", {"score":{"name":"countdown_sec","objective":"has_system"}}, "s"]}
bossbar set minecraft:release_timer_bar players @a