scoreboard players add seeker_count has_system 1
team join has_seeker @s