# Round timer and cooldown management
title @a actionbar [{"text":"Round ends in ","color":"yellow","bold":true},{"score":{"name":"timer_sec","objective":"has_system"}}]
execute as @a[nbt={SelectedItem:{components:{"minecraft:custom_data":{jump_boost:1b}}}}] run title @s actionbar [{"text":"Cooldown: "},{"score":{"name":"@s","objective":"cd_jump_boost"}}]
execute as @a[nbt={SelectedItem:{components:{"minecraft:custom_data":{reveal_seeker:1b}}}}] run title @s actionbar [{"text":"Cooldown: "},{"score":{"name":"@s","objective":"cd_reveal_seeker"}}]
execute as @a[nbt={SelectedItem:{components:{"minecraft:custom_data":{thermometer:1b}}}}] run title @s actionbar [{"text":"Cooldown: "},{"score":{"name":"@s","objective":"cd_thermometer"}}]
execute as @a[nbt={SelectedItem:{components:{"minecraft:custom_data":{xray:1b}}}}] run title @s actionbar [{"text":"Cooldown: "},{"score":{"name":"@s","objective":"cd_xray"}}]

# 30 seconds left: apply final slowdown and reveal hiders to seekers
execute if score timer_sec has_system < 30 has_value run effect give @a[team=has_hider] minecraft:slowness 1 0 true
execute if score timer_sec has_system < 30 has_value as @a run attribute @s minecraft:waypoint_transmit_range base set 60000000

# Check
execute unless entity @a[team=has_hider] run function has:game/seeker_wins
execute as @a[team=has_hider] if score @s deaths matches 1.. run function has:game/assign_seeker

# Time's up
execute if score timer_sec has_system matches 0 run function has:game/hider_wins

# Horror mode jumpscare
execute if score entity_jumpscare_timer has_system < 30 has_value as @a at @s if entity @e[tag=has_entity,distance=..2] run function has:mode_horror/jumpscare
execute if score entity_jumpscare_timer has_system matches 30 run function has:mode_horror/spawn_entity

# Item5
execute unless score xray_step has_system matches 10 run function has:item/raycast_loop
execute as @e[tag=ray] at @s run tp @s ^ ^ ^1
execute as @a[team=has_seeker] if score @s xray_user matches 1 run function has:item/ray_visual