# This function runs every second during the game to manage timers and game phases.
execute if score status has_system matches 1 run scoreboard players add second has_system 1
execute if score second has_system matches 60 run function has:game/minute

# Countdown phase: seeker is locked in
execute if score countdown_sec has_system matches 1.. run function has:game/preparation
execute if score countdown_sec has_system matches 0 run function has:game/release

# Main game phase
execute if score status has_system matches 1 run function has:game/hasing_second
