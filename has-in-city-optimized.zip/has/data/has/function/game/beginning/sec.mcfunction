scoreboard players remove beginning_cd_sec has_system 1

execute as @a at @s run playsound minecraft:block.note_block.hat player @s ~ ~ ~ 0.5 0.5

execute store result bossbar minecraft:has_release_timer_bar value run scoreboard players get beginning_cd_sec has_system
bossbar set minecraft:has_release_timer_bar name {"color":"red", "text":"", "extra": ["Seekers will be released in: ", {"score":{"name":"beginning_cd_sec","objective":"has_system"}}, "s"]}
bossbar set minecraft:has_release_timer_bar players @a

execute if score beginning_cd_sec has_system matches 0..9 as @a at @s run playsound minecraft:block.note_block.hat player @s ~ ~ ~ 0.5 0.5
execute if score beginning_cd_sec has_system matches 0 run function has:game/func/release