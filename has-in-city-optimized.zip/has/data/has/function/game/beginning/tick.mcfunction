tp @a[team=has_seeker] @e[tag=has_spawn_point,limit=1]
execute as @a[team=has_seeker] at @s run tp @s ~ ~ ~ ~ 90.0