scoreboard players set second has_system 0

# Spawn a firework at a random hider's location as a hint
execute at @r[team=has_hider] run summon firework_rocket ~ ~ ~ {LifeTime:30}
tellraw @a {"text":"A firework has been launched at a random hider's location!", "italic": true, "color":"gray"}

execute if score entity_jumpscare_timer has_system matches 0 as @r at @s run spreadplayers ~ ~ 15 30 false @e[tag=has_entity]
execute if score gamemode has_setting matches 2 run playsound minecraft:ambient.cave ambient @a ~ ~ ~ 1 1 1
