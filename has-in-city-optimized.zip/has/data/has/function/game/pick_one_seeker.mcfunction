execute as @r[team=!has_seeker] run function has:game/set_seeker

# Repeat until full
function has:game/fill_seekers