title @a title {"text":"Seekers have won the game!","color":"red","bold":true}
tellraw @a {"text": "Seekers have won the game!", "color": "red", "bold": true}

execute at @a[team=has_seeker] run summon firework_rocket ~ ~ ~ {LifeTime:30,FireworksItem:{id:firework_rocket,count:1,components:{fireworks:{flight_duration:2,explosions:[{shape:"star",has_twinkle:1,has_trail:1,colors:[I;16711680],fade_colors:[I;16711680]}]}}}}
function has:cmd/end
