team join has_seeker @s

give @s minecraft:netherite_sword
give @s minecraft:carrot_on_a_stick[minecraft:custom_data={jump_boost:1b},minecraft:custom_name={text:"Jump Boost (5s)",color:"green"}] 1
give @s minecraft:carrot_on_a_stick[minecraft:custom_data={thermometer:1b},minecraft:custom_name={text:"Thermometer",color:"dark_red"}] 1
give @s minecraft:carrot_on_a_stick[minecraft:custom_data={xray:1b},minecraft:custom_name={text:"X-Ray",color:"gray"}] 1
clear @s minecraft:carrot_on_a_stick[minecraft:custom_data={reveal_seeker:1b}] 1
clear @s minecraft:carrot_on_a_stick[minecraft:custom_data={invisibility:1b}] 1

scoreboard players set @s deaths 0
