# Timer
scoreboard players remove hasing_cd_sec has_system 1
scoreboard players remove hasing_60_sec has_system 1

# A minute
execute if score hasing_60_sec has_system matches 0 run function has:game/hasing/60s

# Item cooldowns
execute as @a[scores={has_cd_reveal_seeker=1..}] run scoreboard players remove @s has_cd_reveal_seeker 1
execute as @a[scores={has_cd_jump_boost=1..}] run scoreboard players remove @s has_cd_jump_boost 1
execute as @a[scores={has_cd_thermometer=1..}] run scoreboard players remove @s has_cd_thermometer 1
execute as @a[scores={has_cd_xray=1..}] run scoreboard players remove @s has_cd_xray 1
execute as @a[scores={has_cd_sensor=1..}] run scoreboard players remove @s has_cd_sensor 1

# 30 seconds left: apply final slowdown and reveal hiders to seekers
execute if score hasing_cd_sec has_system matches 30 run gamerule locator_bar true

# 10 seconds left: play warning sound
execute if score hasing_cd_sec has_system matches 0..9 as @a at @s run playsound minecraft:block.note_block.pling player @s ~ ~ ~ 1 1

# Update vas's brain
execute as @e[tag=has_entity_vas] at @s run data modify entity @s brain.memories.minecraft:attack_target set from entity @p UUID

# Update bossbar
execute store result bossbar minecraft:has_time_remaining_bar value run scoreboard players get hasing_cd_sec has_system
bossbar set minecraft:has_time_remaining_bar name {"color":"yellow", "text":"", "extra": ["Time Remaining: ", {"score":{"name":"hasing_cd_sec","objective":"has_system"}}, "s"]}
bossbar set minecraft:has_time_remaining_bar players @a

scoreboard players remove @e[tag=has_sensor_marker] has_sensor_lifetime 1
execute as @e[tag=has_sensor_marker] if score @s has_sensor_lifetime matches 0 run kill @s

execute as @a[team=has_hider] unless score @s has_invisible_time matches 0 run scoreboard players remove @s has_invisible_time 1
execute as @a[team=has_hider] unless score @s has_invisible_time matches 0 run title @s actionbar {"text": "", "color": "aqua", "extra": [{"text": "Invisibility: "}, {"score": {"name": "@s", "objective": "has_invisible_time"}}]}
