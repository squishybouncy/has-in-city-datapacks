# Round timer and cooldown management
execute as @a run function has:item/func/check_item_use
execute as @a[nbt={SelectedItem:{components:{"minecraft:custom_data":{has_jump_boost:1b}}}}] run title @s actionbar [{"text":"Cooldown: "},{"score":{"name":"@s","objective":"has_cd_jump_boost"}}]
execute as @a[nbt={SelectedItem:{components:{"minecraft:custom_data":{has_reveal_seeker:1b}}}}] run title @s actionbar [{"text":"Cooldown: "},{"score":{"name":"@s","objective":"has_cd_reveal_seeker"}}]
execute as @a[nbt={SelectedItem:{components:{"minecraft:custom_data":{has_thermometer:1b}}}}] run title @s actionbar [{"text":"Cooldown: "},{"score":{"name":"@s","objective":"has_cd_thermometer"}}]
execute as @a[nbt={SelectedItem:{components:{"minecraft:custom_data":{has_xray:1b}}}}] run title @s actionbar [{"text":"Cooldown: "},{"score":{"name":"@s","objective":"has_cd_xray"}}]
execute as @a[nbt={SelectedItem:{components:{"minecraft:custom_data":{has_sensor:1b}}}}] run title @s actionbar [{"text":"Cooldown: "},{"score":{"name":"@s","objective":"has_cd_sensor"}}]

# 30 seconds left: apply final slowdown
execute if score hasing_cd_sec has_system matches 30 run effect give @a[team=has_hider] minecraft:slowness 30 0 true

# Time's up / Hider wins
execute if score hasing_cd_sec has_system matches 0 run function has:game/func/hider_wins

# Check win conditions / Seekers win if no hiders remain
execute unless entity @e[team=has_hider] run function has:game/func/seeker_wins

# Convert hider to seeker
execute as @a[team=has_hider] if score @s has_deaths matches 1.. run function has:game/seeker_mgmt/assign_seeker

# Horror mode jumpscare
execute if score entity_vas_jumpscare_timer has_system matches 0.. as @a at @s if entity @e[tag=has_entity_vas,distance=..2] run function has:game/func/entity_vas_jumpscare
execute if score entity_vas_jumpscare_timer has_system matches 30 run function has:game/func/spawn_entity_vas

# Xray visual and raycasting
execute unless score xray_step has_system matches 10 run function has:item/xray_mgmt/raycast_loop
execute as @e[tag=has_xray] at @s run tp @s ^ ^ ^1
execute as @a[team=has_seeker] if score @s has_xray_user matches 1 run function has:item/xray_mgmt/ray_visual

# Decoy kill detection
execute as @e[tag=has_decoy_marker] at @s unless entity @e[tag=has_decoy,distance=..2] as @a[team=has_seeker,sort=nearest,distance=..6,limit=1] run function has:item/decoy_mgmt/decoy_killed

# Sensor detection
execute as @e[tag=has_sensor_marker] at @s run particle minecraft:electric_spark ~ ~ ~ 2 2 2 0 10
execute as @e[tag=has_sensor_marker] at @s as @e[tag=has_detectable,distance=..5] if score @s has_invisible_time matches 0 run function has:item/sensor_mgmt/sensor_detect