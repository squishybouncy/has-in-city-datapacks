scoreboard players set countdown_sec has_system -1
scoreboard players set status has_system 1

effect clear @a[team=has_seeker]
execute as @a[team=has_seeker] run function has:game/assign_seeker

give @a[team=has_hider] minecraft:carrot_on_a_stick[minecraft:custom_data={reveal_seeker:1b},minecraft:custom_name={text:"Reveal Seeker (5s)",color:"gold"}] 1
give @a[team=has_hider] minecraft:carrot_on_a_stick[minecraft:custom_data={invisibility:1b},minecraft:custom_name={text:"Invisibility (3s) <One Time Use>",color:"aqua"}] 1

execute if score gamemode has_setting matches 2 run function has:mode_horror/spawn_entity

title @a title {"text":"Seeker has been released!","color":"red","bold":true}
