scoreboard players set countdown_sec has_system -1
scoreboard players set status has_system 1

effect clear @a[team=has_seeker]
execute as @a[team=has_seeker] run function has:game/assign_seeker

give @a[team=has_hider] minecraft:wooden_shovel[minecraft:custom_name={text:"Knockback Stick <3 Uses>",color:"yellow"},damage=54,enchantments={knockback:3}] 1
give @a[team=has_hider] minecraft:carrot_on_a_stick[minecraft:custom_data={reveal_seeker:1b},minecraft:custom_name={text:"Reveal Seeker (5s)",color:"gold"}] 1
give @a[team=has_hider] minecraft:carrot_on_a_stick[minecraft:custom_data={invisibility:1b},minecraft:custom_name={text:"Invisibility (5s) <One Use>",color:"aqua"}] 1
give @a[team=has_hider] minecraft:carrot_on_a_stick[minecraft:custom_data={decoy:1b},minecraft:custom_name={text:"Spawn a Decoy <One Use>",color:"light_purple"}] 1

execute if score gamemode has_setting matches 2 run function has:mode_horror/spawn_entity

title @a title {"text":"Seekers have been released!","color":"red","bold":true}
playsound minecraft:block.end_portal.spawn master @a ~ ~ ~ 1 1

execute store result bossbar minecraft:time_remaining_bar max run scoreboard players get timer_sec has_system
bossbar set minecraft:release_timer_bar visible false
bossbar set minecraft:time_remaining_bar visible true
