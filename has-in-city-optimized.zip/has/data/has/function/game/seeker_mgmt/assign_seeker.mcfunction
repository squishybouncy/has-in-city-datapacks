team join has_seeker @s

clear @s minecraft:carrot_on_a_stick 10
clear @s minecraft:wooden_shovel 1

give @s minecraft:netherite_sword
give @s minecraft:carrot_on_a_stick[minecraft:custom_data={has_jump_boost:1b},minecraft:custom_name={text:"Jump Boost (5s)",color:"green"}] 1
give @s minecraft:carrot_on_a_stick[minecraft:custom_data={has_thermometer:1b},minecraft:custom_name={text:"Thermometer",color:"dark_red"}] 1
give @s minecraft:carrot_on_a_stick[minecraft:custom_data={has_xray:1b},minecraft:custom_name={text:"X-Ray",color:"gray"}] 1
give @s minecraft:carrot_on_a_stick[minecraft:custom_data={has_sensor:1b},minecraft:custom_name={text:"Sensor (60s)",color:"blue"}] 1

scoreboard players set @s has_deaths 0
