execute as @r[team=!has_seeker] run function has:game/seeker_mgmt/set_seeker

# Repeat until full
function has:game/seeker_mgmt/fill_seekers