execute if score gamemode has_setting matches 2 run effect give @a minecraft:blindness 100 0 true
execute if score gamemode has_setting matches 2 run effect give @a minecraft:slowness 100 1 true