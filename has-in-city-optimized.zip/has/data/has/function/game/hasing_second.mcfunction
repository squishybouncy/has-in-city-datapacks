# Timer
scoreboard players remove timer_sec has_system 1

# Cooldown
execute as @a[scores={cd_reveal_seeker=1..}] run scoreboard players remove @s cd_reveal_seeker 1
execute as @a[scores={cd_jump_boost=1..}] run scoreboard players remove @s cd_jump_boost 1
execute as @a[scores={cd_thermometer=1..}] run scoreboard players remove @s cd_thermometer 1
execute as @a[scores={cd_xray=1..}] run scoreboard players remove @s cd_xray 1

# 30 seconds left: apply final slowdown and reveal hiders to seekers
execute if score timer_sec has_system matches 30 run gamerule locator_bar true