# Timer
scoreboard players remove timer_sec has_system 1

# Cooldown
execute as @a[scores={cd_reveal_seeker=1..}] run scoreboard players remove @s cd_reveal_seeker 1
execute as @a[scores={cd_jump_boost=1..}] run scoreboard players remove @s cd_jump_boost 1
execute as @a[scores={cd_thermometer=1..}] run scoreboard players remove @s cd_thermometer 1
execute as @a[scores={cd_xray=1..}] run scoreboard players remove @s cd_xray 1

# 30 seconds left: apply final slowdown and reveal hiders to seekers
execute if score timer_sec has_system matches 30 run gamerule locator_bar true

execute if score timer_sec has_system matches 0..5 run playsound minecraft:block.note_block.pling master @a ~ ~ ~ 1 1

execute as @e[tag=has_entity] at @s run data modify entity @s brain.memories.minecraft:attack_target set from entity @p UUID

execute store result bossbar minecraft:time_remaining_bar value run scoreboard players get timer_sec has_system
bossbar set minecraft:time_remaining_bar name {"color":"yellow", "text":"", "extra": ["Time Remaining: ", {"score":{"name":"timer_sec","objective":"has_system"}}, "s"]}
bossbar set minecraft:time_remaining_bar players @a
