execute at @s run worldborder center ~ ~
