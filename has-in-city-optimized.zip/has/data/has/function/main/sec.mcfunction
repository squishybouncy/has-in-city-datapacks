# This function runs every second during the game to manage timers and game phases.
scoreboard players set game_tick has_system 0

# Countdown phase: seeker is locked in
execute if score game_state has_system matches 1 run function has:game/beginning/sec

# Main game phase
execute if score game_state has_system matches 2 run function has:game/hasing/sec