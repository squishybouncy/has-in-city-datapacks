# --- Teams ---
team add has_hider Hider
team add has_seeker Seeker
team add has_spectator Spectator
team add has_intermission Intermission

team modify has_hider color blue
team modify has_seeker color red
team modify has_spectator color gray
team modify has_intermission color yellow

team modify has_hider friendlyFire false
team modify has_seeker friendlyFire false
team modify has_spectator friendlyFire false

team modify has_hider nametagVisibility hideForOtherTeams
team modify has_hider nametagVisibility hideForOwnTeam
team modify has_seeker nametagVisibility hideForOtherTeams

# --- Scoreboards ---
scoreboard objectives add has_setting dummy
scoreboard players set countdown has_setting 1
scoreboard players set timer has_setting 1
scoreboard players set border has_setting 1
scoreboard players set shrink has_setting 0
scoreboard players set seeker has_setting 1

scoreboard objectives add has_system dummy
scoreboard players set tick has_system 0

scoreboard objectives add has_value dummy
scoreboard players set 30 has_value 30

scoreboard objectives add deaths deathCount
scoreboard objectives add useItem minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add useItemLast dummy
scoreboard objectives add cd_jump_boost dummy

scoreboard objectives add isHost dummy

# --- World Rules ---
gamerule keep_inventory true

function has:cmd/reset
function has:cmd/help
