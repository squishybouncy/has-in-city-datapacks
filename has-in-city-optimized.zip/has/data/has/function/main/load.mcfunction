# --- Teams ---
team add has_hider Hider
team add has_decoy Decoy
team add has_seeker Seeker
team add has_spectator Spectator
team add has_intermission Intermission
team add has_next_seeker NextSeeker

team modify has_hider color blue
team modify has_decoy color blue
team modify has_seeker color red
team modify has_spectator color gray
team modify has_intermission color yellow
team modify has_next_seeker color dark_red

team modify has_hider friendlyFire false
team modify has_seeker friendlyFire false
team modify has_spectator friendlyFire false

team modify has_hider nametagVisibility never
team modify has_decoy nametagVisibility never
team modify has_seeker nametagVisibility hideForOtherTeams

# --- Scoreboards ---
scoreboard objectives remove has_setting
scoreboard objectives add has_setting dummy
scoreboard players set countdown has_setting 10
scoreboard players set timer has_setting 300
scoreboard players set seeker has_setting 0
scoreboard players set gamemode has_setting 1
scoreboard players set decoy_detectable has_setting 0

scoreboard objectives remove has_system
scoreboard objectives add has_system dummy
scoreboard objectives add has_deaths deathCount
scoreboard objectives add has_useItem minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add has_useItemLast dummy
scoreboard objectives add has_cd_reveal_seeker dummy
scoreboard objectives add has_cd_jump_boost dummy
scoreboard objectives add has_cd_thermometer dummy
scoreboard objectives add has_cd_xray dummy
scoreboard objectives add has_cd_sensor dummy
scoreboard objectives add has_temperature dummy
scoreboard objectives add has_xray_user dummy
scoreboard objectives add has_decoy_killed dummy
scoreboard objectives add has_sensor_lifetime dummy
scoreboard objectives add has_invisible_time dummy
scoreboard objectives add has_isHost dummy

bossbar add minecraft:has_release_timer_bar ""
bossbar set minecraft:has_release_timer_bar color red
bossbar set minecraft:has_release_timer_bar style progress

bossbar add minecraft:has_time_remaining_bar ""
bossbar set minecraft:has_time_remaining_bar color yellow
bossbar set minecraft:has_time_remaining_bar style progress

# --- World Rules ---
gamerule keep_inventory true
gamerule mob_drops false

function has:cmd/reset
function has:cmd/help
