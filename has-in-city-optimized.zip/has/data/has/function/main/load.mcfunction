# --- Teams ---
team add has_hider Hider
team add has_seeker Seeker
team add has_spectator Spectator
team add has_intermission Intermission
team add has_next_seeker NextSeeker

team modify has_hider color blue
team modify has_seeker color red
team modify has_spectator color gray
team modify has_intermission color yellow
team modify has_next_seeker color dark_red

team modify has_hider friendlyFire false
team modify has_seeker friendlyFire false
team modify has_spectator friendlyFire false

team modify has_hider nametagVisibility never
team modify has_seeker nametagVisibility hideForOtherTeams

# --- Scoreboards ---
scoreboard objectives add has_setting dummy
scoreboard players set countdown has_setting 60
scoreboard players set timer has_setting 300
scoreboard players set seeker has_setting 1

# HAS Gamemode  1: Normal 2: Horror
scoreboard players set gamemode has_setting 1

scoreboard objectives add has_system dummy
scoreboard players set tick has_system 0
scoreboard players set active has_system 0
scoreboard players set status has_system 0
scoreboard players set xray_step has_system 10
scoreboard players set xray_detected has_system 0

scoreboard players set seeker_count has_system 0

scoreboard players set entity_jumpscare_timer has_system 0

scoreboard objectives add has_value dummy
scoreboard players set 0 has_value 0
scoreboard players set 30 has_value 30

scoreboard objectives add deaths deathCount
scoreboard objectives add useItem minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add useItemLast dummy
scoreboard objectives add cd_reveal_seeker dummy
scoreboard objectives add cd_jump_boost dummy
scoreboard objectives add cd_thermometer dummy
scoreboard objectives add cd_xray dummy

scoreboard objectives add temperature dummy
scoreboard objectives add xray_user dummy
scoreboard objectives add decoy_killed dummy

scoreboard objectives add isHost dummy

bossbar add minecraft:release_timer_bar ""
bossbar set minecraft:release_timer_bar color red
bossbar set minecraft:release_timer_bar style progress

bossbar add minecraft:time_remaining_bar ""
bossbar set minecraft:time_remaining_bar color yellow
bossbar set minecraft:time_remaining_bar style progress

# --- World Rules ---
gamerule keep_inventory true
gamerule mob_drops false

function has:cmd/reset
function has:cmd/help
