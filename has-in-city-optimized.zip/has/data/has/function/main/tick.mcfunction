# This function runs every tick to manage game state, player effects, and item usage.
execute if score game_tick has_system matches 20 run function has:main/sec
execute if score game_state has_system matches 1.. run scoreboard players add game_tick has_system 1
execute if score game_state has_system matches 1 run function has:game/beginning/tick

# Seeker always has resistance + speed
effect give @a[team=has_seeker] minecraft:resistance 1 255 true
effect give @a[team=has_seeker] minecraft:speed 1 0 true

# Global effects
effect give @a minecraft:fire_resistance 1 0 true
effect give @a minecraft:saturation 1 0 true

# Non-seekers can't hold netherite swords (also prevents them from dropping it and accidentally hitting seekers with it)
clear @a[team=!has_seeker] minecraft:netherite_sword
attribute @s minecraft:fall_damage_multiplier base set 0.35

execute if score gamemode has_setting matches 2 run effect give @a minecraft:blindness 100 0 true
execute if score gamemode has_setting matches 2 run effect give @a[team=has_hider] minecraft:slowness 100 0 true

# Check for item usage and apply effects accordingly
execute if score game_state has_system matches 2 run function has:game/hasing/tick
