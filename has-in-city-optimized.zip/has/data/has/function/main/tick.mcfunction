execute if score active has_system matches 1 run scoreboard players add tick has_system 1
execute if score tick has_system matches 20 run function has:game/second
execute if score tick has_system matches 20 run scoreboard players set tick has_system 0

execute if score active has_system matches 1 run function has:game/game_active
execute if score status has_system matches 0 run tp @a[team=has_seeker] @e[tag=has_spawn_point,limit=1]
execute if score status has_system matches 0 as @a[team=has_seeker] at @s run tp @s ~ ~ ~ ~ 90.0

# Seeker always has resistance + speed
effect give @a[team=has_seeker] minecraft:resistance 1 255 true
effect give @a[team=has_seeker] minecraft:speed 1 0 true

# Global effects
effect give @a minecraft:fire_resistance 1 0 true
effect give @a minecraft:saturation 1 0 true

# Non-seekers can't hold netherite swords (also prevents them from dropping it and accidentally hitting seekers with it)
clear @a[team=!has_seeker] minecraft:netherite_sword
attribute @s minecraft:fall_damage_multiplier base set 0.35

execute as @a run function has:item/check_item_use
execute if score status has_system matches 1 run function has:game/hasing_tick
