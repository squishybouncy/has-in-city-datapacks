clear @s minecraft:carrot_on_a_stick[minecraft:custom_data={decoy:1b}] 1
execute at @s run summon minecraft:mannequin ~ ~ ~ {Tags:["has_decoy"],Passengers:[{id:"minecraft:armor_stand",Tags:["has_decoy_marker"],Invisible:1b}]}
execute at @s run data modify entity @e[tag=has_decoy,limit=1,sort=nearest] profile.id set from entity @s UUID
execute at @s run data modify entity @e[tag=has_decoy,limit=1,sort=nearest] Rotation set from entity @s Rotation
tellraw @s {"text": "Decoy spawned!", "italic": true, "color": "light_purple"}