scoreboard players set @s cd_xray 60
scoreboard players set @s xray_user 1
scoreboard players set xray_step has_system 0
scoreboard players set xray_detected has_system 0

execute at @s rotated as @s run summon armor_stand ^ ^ ^1 {Invisible:1b,NoGravity:1b,Tags:["ray"]}
execute at @s run tp @e[tag=ray] ~ ~ ~ ~ ~