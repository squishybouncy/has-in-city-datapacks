execute if score @s useItem > @s useItemLast run function has:item/handle_item
