execute if score @s has_useItem > @s has_useItemLast run function has:item/func/handle_item
