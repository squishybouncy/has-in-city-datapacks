# Reveal Seeker
execute as @s[nbt={SelectedItem:{components:{"minecraft:custom_data":{has_reveal_seeker:1b}}}}] if score @s has_cd_reveal_seeker matches 0 run function has:item/trigger/reveal_seeker

# Jump Boost
execute as @s[nbt={SelectedItem:{components:{"minecraft:custom_data":{has_jump_boost:1b}}}}] if score @s has_cd_jump_boost matches 0 run function has:item/trigger/jump_boost

# Invisibility
execute as @s[nbt={SelectedItem:{components:{"minecraft:custom_data":{has_invisibility:1b}}}}] run function has:item/trigger/invisibility

# Thermometer
execute as @s[nbt={SelectedItem:{components:{"minecraft:custom_data":{has_thermometer:1b}}}}] if score @s has_cd_thermometer matches 0 run function has:item/trigger/thermometer

# X-Ray
execute as @s[nbt={SelectedItem:{components:{"minecraft:custom_data":{has_xray:1b}}}}] if score @s has_cd_xray matches 0 if score xray_step has_system matches 10 run function has:item/trigger/xray

# Decoy
execute as @s[nbt={SelectedItem:{components:{"minecraft:custom_data":{has_decoy:1b}}}}] run function has:item/trigger/decoy

# Sensor
execute as @s[nbt={SelectedItem:{components:{"minecraft:custom_data":{has_sensor:1b}}}}] if score @s has_cd_sensor matches 0 run function has:item/trigger/sensor

scoreboard players operation @s has_useItemLast = @s has_useItem