scoreboard players set @s has_cd_reveal_seeker 60
effect give @a[team=has_seeker] minecraft:glowing 5 0 true
tellraw @a {"text": "Seekers has been revealed for 5 seconds!", "italic": true, "color": "gold"}
execute at @a run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1
