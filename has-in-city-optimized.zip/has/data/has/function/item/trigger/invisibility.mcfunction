clear @s minecraft:carrot_on_a_stick[minecraft:custom_data={has_invisibility:1b}] 1
effect give @s minecraft:invisibility 5 0 true
scoreboard players set @s has_invisible_time 5
tellraw @s {"text": "You are now invisible for 5 seconds!", "italic": true, "color": "aqua"}
execute at @s run playsound minecraft:block.brewing_stand.brew player @s ~ ~ ~ 1 1
