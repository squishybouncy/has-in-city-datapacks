scoreboard players set @s has_cd_sensor 120
execute at @s run summon armor_stand ~ ~ ~ {Tags:["has_sensor_marker"],Invisible:1b,Invulnerable:1b,NoGravity:1b,Marker:1b}
execute at @s as @e[tag=has_sensor_marker,sort=nearest,limit=1] run scoreboard players set @s has_sensor_lifetime 60
tellraw @s {"text": "Sensor has been installed!", "italic": true, "color": "blue"}
execute at @s run playsound minecraft:block.smithing_table.use ambient @s ~ ~ ~ 1 1