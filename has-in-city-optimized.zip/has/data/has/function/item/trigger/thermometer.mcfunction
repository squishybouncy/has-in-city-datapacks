scoreboard players set @s has_cd_thermometer 60
execute at @s run playsound minecraft:block.note_block.bell player @s ~ ~ ~ 1 1

execute at @s if entity @e[distance=60..,tag=has_detectable] run scoreboard players set @s has_temperature 0
execute at @s if entity @e[distance=..60,tag=has_detectable] run scoreboard players set @s has_temperature 1
execute at @s if entity @e[distance=..25,tag=has_detectable] run scoreboard players set @s has_temperature 2
execute at @s if entity @e[distance=..10,tag=has_detectable] run scoreboard players set @s has_temperature 3

execute if score @s has_temperature matches 0 run tellraw @s {"text": "Temperature: Cold >60", "italic": true, "color": "dark_aqua"}
execute if score @s has_temperature matches 1 run tellraw @s {"text": "Temperature: Medium <60", "italic": true, "color": "gray"}
execute if score @s has_temperature matches 2 run tellraw @s {"text": "Temperature: Warm <25", "italic": true, "color": "red"}
execute if score @s has_temperature matches 3 run tellraw @s {"text": "Temperature: Hot <10", "italic": true, "color": "dark_red"}
scoreboard players set @s has_temperature 0