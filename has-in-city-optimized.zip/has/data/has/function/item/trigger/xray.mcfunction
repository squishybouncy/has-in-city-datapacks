scoreboard players set @s has_cd_xray 60
scoreboard players set @s has_xray_user 1
scoreboard players set xray_step has_system 0
scoreboard players set xray_detected has_system 0

execute at @s rotated as @s run summon armor_stand ^ ^ ^1 {Invisible:1b,NoGravity:1b,Tags:["has_xray"]}
execute at @s run tp @e[tag=has_xray] ~ ~ ~ ~ ~
execute at @s run playsound minecraft:block.note_block.imitate.creeper player @s ~ ~ ~ 1 1