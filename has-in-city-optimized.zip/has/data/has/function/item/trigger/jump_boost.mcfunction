scoreboard players set @s has_cd_jump_boost 30
effect give @s minecraft:jump_boost 5 1 true
tellraw @s {"text": "You are now jumping higher for 5 seconds!", "italic": true, "color": "dark_green"}
execute at @s run playsound minecraft:entity.slime.jump master @s ~ ~ ~ 5 1

