scoreboard players set @s cd_thermometer 60
execute at @s if entity @a[distance=..100,team=has_hider] run scoreboard players set @s temperature 1
execute at @s if entity @a[distance=..60,team=has_hider] run scoreboard players set @s temperature 2
execute at @s if entity @a[distance=..25,team=has_hider] run scoreboard players set @s temperature 3
execute at @s if entity @a[distance=..10,team=has_hider] run scoreboard players set @s temperature 4
execute if score @s temperature matches 1 run tellraw @s {"text": "Temperature: Cold", "italic": true, "color": "dark_aqua"}
execute if score @s temperature matches 2 run tellraw @s {"text": "Temperature: Medium", "italic": true, "color": "gray"}
execute if score @s temperature matches 3 run tellraw @s {"text": "Temperature: Warm", "italic": true, "color": "red"}
execute if score @s temperature matches 4 run tellraw @s {"text": "Temperature: Hot", "italic": true, "color": "dark_red"}