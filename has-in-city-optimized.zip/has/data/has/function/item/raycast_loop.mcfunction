scoreboard players add xray_step has_system 1
execute as @e[tag=ray] at @s run tp @s ^ ^ ^3

execute as @e[tag=ray] at @s if score xray_step has_system matches 1 if entity @a[team=has_hider,distance=..2] run scoreboard players set xray_detected has_system 1
execute as @e[tag=ray] at @s if score xray_step has_system matches 2 if entity @a[team=has_hider,distance=..4] run scoreboard players set xray_detected has_system 1
execute as @e[tag=ray] at @s if score xray_step has_system matches 3 if entity @a[team=has_hider,distance=..6] run scoreboard players set xray_detected has_system 1
execute as @e[tag=ray] at @s if score xray_step has_system matches 4 if entity @a[team=has_hider,distance=..8] run scoreboard players set xray_detected has_system 1
execute as @e[tag=ray] at @s if score xray_step has_system matches 5 if entity @a[team=has_hider,distance=..10] run scoreboard players set xray_detected has_system 1
execute as @e[tag=ray] at @s if score xray_step has_system matches 6 if entity @a[team=has_hider,distance=..12] run scoreboard players set xray_detected has_system 1
execute as @e[tag=ray] at @s if score xray_step has_system matches 7 if entity @a[team=has_hider,distance=..14] run scoreboard players set xray_detected has_system 1
execute as @e[tag=ray] at @s if score xray_step has_system matches 8 if entity @a[team=has_hider,distance=..16] run scoreboard players set xray_detected has_system 1
execute as @e[tag=ray] at @s if score xray_step has_system matches 9 if entity @a[team=has_hider,distance=..18] run scoreboard players set xray_detected has_system 1
execute as @e[tag=ray] at @s if score xray_step has_system matches 10 if entity @a[team=has_hider,distance=..20] run scoreboard players set xray_detected has_system 1

execute as @e[tag=ray] at @s if score xray_step has_system matches 1 if entity @e[team=has_hider,distance=..2] run scoreboard players set xray_detected has_system 1
execute as @e[tag=ray] at @s if score xray_step has_system matches 2 if entity @e[team=has_hider,distance=..4] run scoreboard players set xray_detected has_system 1
execute as @e[tag=ray] at @s if score xray_step has_system matches 3 if entity @e[team=has_hider,distance=..6] run scoreboard players set xray_detected has_system 1
execute as @e[tag=ray] at @s if score xray_step has_system matches 4 if entity @e[team=has_hider,distance=..8] run scoreboard players set xray_detected has_system 1
execute as @e[tag=ray] at @s if score xray_step has_system matches 5 if entity @e[team=has_hider,distance=..10] run scoreboard players set xray_detected has_system 1
execute as @e[tag=ray] at @s if score xray_step has_system matches 6 if entity @e[team=has_hider,distance=..12] run scoreboard players set xray_detected has_system 1
execute as @e[tag=ray] at @s if score xray_step has_system matches 7 if entity @e[team=has_hider,distance=..14] run scoreboard players set xray_detected has_system 1
execute as @e[tag=ray] at @s if score xray_step has_system matches 8 if entity @e[team=has_hider,distance=..16] run scoreboard players set xray_detected has_system 1
execute as @e[tag=ray] at @s if score xray_step has_system matches 9 if entity @e[team=has_hider,distance=..18] run scoreboard players set xray_detected has_system 1
execute as @e[tag=ray] at @s if score xray_step has_system matches 10 if entity @e[team=has_hider,distance=..20] run scoreboard players set xray_detected has_system 1

execute if score xray_step has_system matches 10 run function has:item/xray_stop