clear @s minecraft:carrot_on_a_stick[minecraft:custom_data={invisibility:1b}] 1
effect give @s minecraft:invisibility 3 0 true
tellraw @s {"text": "You are now invisible for 3 seconds!", "italic": true, "color": "aqua"}
