execute at @s anchored eyes run particle minecraft:copper_fire_flame ~ ~1.6 ~ ^3500 ^3500 ^10000 0.0001 0
execute at @s anchored eyes run particle minecraft:copper_fire_flame ~ ~1.6 ~ ^-3500 ^3500 ^10000 0.0001 0
execute at @s anchored eyes run particle minecraft:copper_fire_flame ~ ~1.6 ~ ^3500 ^-3500 ^10000 0.0001 0
execute at @s anchored eyes run particle minecraft:copper_fire_flame ~ ~1.6 ~ ^-3500 ^-3500 ^10000 0.0001 0

execute at @s anchored eyes run particle minecraft:copper_fire_flame ~ ~1.6 ~ ^-5000 ^ ^10000 0.0001 0
execute at @s anchored eyes run particle minecraft:copper_fire_flame ~ ~1.6 ~ ^5000 ^ ^10000 0.0001 0
execute at @s anchored eyes run particle minecraft:copper_fire_flame ~ ~1.6 ~ ^ ^-5000 ^10000 0.0001 0
execute at @s anchored eyes run particle minecraft:copper_fire_flame ~ ~1.6 ~ ^ ^5000 ^10000 0.0001 0