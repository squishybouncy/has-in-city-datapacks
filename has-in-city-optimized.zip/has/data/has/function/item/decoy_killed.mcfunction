kill @e[tag=has_decoy_marker,sort=nearest,limit=1]
effect give @s glowing 5 0 true
effect give @s blindness 5 0 true
effect give @s slowness 5 2 true
playsound minecraft:entity.elder_guardian.curse master @s ~ ~ ~ 1 1