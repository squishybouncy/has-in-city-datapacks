scoreboard players add xray_step has_system 1
execute as @e[tag=has_xray] at @s run tp @s ^ ^ ^3

execute as @e[tag=has_xray] at @s if score xray_step has_system matches 1 if entity @e[distance=..2,tag=has_detectable] run scoreboard players set xray_detected has_system 1
execute as @e[tag=has_xray] at @s if score xray_step has_system matches 2 if entity @e[distance=..4,tag=has_detectable] run scoreboard players set xray_detected has_system 1
execute as @e[tag=has_xray] at @s if score xray_step has_system matches 3 if entity @e[distance=..6,tag=has_detectable] run scoreboard players set xray_detected has_system 1
execute as @e[tag=has_xray] at @s if score xray_step has_system matches 4 if entity @e[distance=..8,tag=has_detectable] run scoreboard players set xray_detected has_system 1
execute as @e[tag=has_xray] at @s if score xray_step has_system matches 5 if entity @e[distance=..10,tag=has_detectable] run scoreboard players set xray_detected has_system 1
execute as @e[tag=has_xray] at @s if score xray_step has_system matches 6 if entity @e[distance=..12,tag=has_detectable] run scoreboard players set xray_detected has_system 1
execute as @e[tag=has_xray] at @s if score xray_step has_system matches 7 if entity @e[distance=..14,tag=has_detectable] run scoreboard players set xray_detected has_system 1
execute as @e[tag=has_xray] at @s if score xray_step has_system matches 8 if entity @e[distance=..16,tag=has_detectable] run scoreboard players set xray_detected has_system 1
execute as @e[tag=has_xray] at @s if score xray_step has_system matches 9 if entity @e[distance=..18,tag=has_detectable] run scoreboard players set xray_detected has_system 1
execute as @e[tag=has_xray] at @s if score xray_step has_system matches 10 if entity @e[distance=..20,tag=has_detectable] run scoreboard players set xray_detected has_system 1

execute if score xray_step has_system matches 10 run function has:item/xray_mgmt/stop