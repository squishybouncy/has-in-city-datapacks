kill @e[tag=has_xray]
execute as @a if score @s has_xray_user matches 1 if score xray_detected has_system matches 1 run tellraw @s {"text":"X-Ray: Hider detected in sight!","color":"dark_green"}
execute as @a if score @s has_xray_user matches 1 if score xray_detected has_system matches 0 run tellraw @s {"text":"X-Ray: No hider detected in sight!.","color":"dark_gray"}
scoreboard players set @a has_xray_user 0