effect give @s minecraft:glowing 1 0 true
title @s actionbar {"text": "You have been detected by a sensor!", "italic": true, "color": "red"}
execute at @s run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 1 1