# Reveal Seeker
execute as @s[nbt={SelectedItem:{components:{"minecraft:custom_data":{reveal_seeker:1b}}}}] if score @s cd_reveal_seeker matches 0 run function has:item/item1

# Jump Boost
execute as @s[nbt={SelectedItem:{components:{"minecraft:custom_data":{jump_boost:1b}}}}] if score @s cd_jump_boost matches 0 run function has:item/item2

# Invisibility
execute as @s[nbt={SelectedItem:{components:{"minecraft:custom_data":{invisibility:1b}}}}] run function has:item/item3

# Thermometer
execute as @s[nbt={SelectedItem:{components:{"minecraft:custom_data":{thermometer:1b}}}}] if score @s cd_thermometer matches 0 run function has:item/item4

# X-Ray
execute as @s[nbt={SelectedItem:{components:{"minecraft:custom_data":{xray:1b}}}}] if score @s cd_xray matches 0 if score xray_step has_system matches 10 run function has:item/item5

# Decoy
execute as @s[nbt={SelectedItem:{components:{"minecraft:custom_data":{decoy:1b}}}}] run function has:item/item6

scoreboard players operation @s useItemLast = @s useItem
