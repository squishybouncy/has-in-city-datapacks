execute if score @s useItem > @s useItemLast run function has:handle_item
